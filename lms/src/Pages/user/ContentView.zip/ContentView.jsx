import React, { useEffect, useState } from "react";
import ReactPlayer from "react-player";
import { FaArrowRight, FaArrowLeft } from "react-icons/fa";
import { IoSearchOutline } from "react-icons/io5";
import { IoIosArrowDown, IoIosArrowUp } from "react-icons/io";
import { HiOutlinePlay } from "react-icons/hi";
import { useParams } from "react-router-dom";
import axiosInstance from "../../components/axiosInstance";
import Sidebar from "../../components/Sidebar";

const ContentView = () => {
  const { name } = useParams();
  const [videoData, setVideoData] = useState([]);
  const [Course, setCourse] = useState(null);
  const [feedBackData, setFeedBack] = useState([]);
  const [loading, setLoading] = useState(false);
  const [Openvisible, setOpenVisible] = useState(false);
  const [Previewid, setPreviewId] = useState(null);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0); // Track current chapter
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchCourse = async () => {
      setLoading(true);
      try {
        const response = await axiosInstance.get("/courses/getAll");
        const filter = response.data.find((data) => data.course_name === name);
        const videoResponse = await axiosInstance.post(
          "/chapters/getVideosByChapters",
          { idCourses: filter.idCourses }
        );
        setVideoData(videoResponse.data);
        setCourse(filter);
      } catch (error) {
        console.error("Error fetching course data:", error);
      }
      setLoading(false);
    };

    const fetchFeedback = async () => {
      try {
        const response = await axiosInstance.get("/feedbacks/getAll");
        setFeedBack(response.data);
      } catch (error) {
        console.error("Error fetching feedback:", error);
      }
    };

    fetchCourse();
    fetchFeedback();
  }, [name]);

  // const handlePreviewReply = (id) => {
  //   setPreviewId((prevPreviewId) => (prevPreviewId === id ? null : id));
  //   setOpenVisible((prevState) => !prevState);
  // };

  const handlePreviewReply = (id) => {
    // Toggle the visibility of the chapter video list
    if (Previewid === id) {
      setPreviewId(null); // Close the list if the same chapter is clicked again
      setOpenVisible(false);
    } else {
      setPreviewId(id); // Set the clicked chapter's id as the previewId
      setOpenVisible(true);
    }
  };

  const handleOpenVideo = (video) => {
    // Find the corresponding chapter index and video index
    const chapterIndex = videoData.findIndex(
      (chapter) => chapter.idChapters === video.idChapters
    );
    const videoIndex = videoData[chapterIndex]?.Videos.findIndex(
      (v) => v.id === video.id
    );

    if (chapterIndex !== -1 && videoIndex !== -1) {
      // Update the state for the current video and chapter
      setCurrentChapterIndex(chapterIndex);
      setCurrentVideoIndex(videoIndex);
      setPreviewId(video.idChapters); // Ensure the video gets played when clicked
    }
  };

  const handleVideoChange = (direction) => {
    // Ensure we are changing video within the current chapter
    setCurrentVideoIndex((prevIndex) =>
      direction === "next"
        ? Math.min(
            prevIndex + 1,
            videoData[currentChapterIndex]?.Videos.length - 1
          )
        : Math.max(prevIndex - 1, 0)
    );

    // If we go beyond the current chapter's video list, move to the next chapter
    if (
      direction === "next" &&
      currentVideoIndex === videoData[currentChapterIndex]?.Videos.length - 1
    ) {
      setCurrentChapterIndex((prevIndex) =>
        Math.min(prevIndex + 1, videoData.length - 1)
      );
      setCurrentVideoIndex(0); // Reset video index for new chapter
    }

    // If we go before the first video, move to the previous chapter
    if (direction === "prev" && currentVideoIndex === 0) {
      setCurrentChapterIndex((prevIndex) => Math.max(prevIndex - 1, 0));
      setCurrentVideoIndex(videoData[currentChapterIndex]?.Videos.length - 1); // Set to last video of the previous chapter
    }
  };

  const currentVideo =
    videoData[currentChapterIndex]?.Videos[currentVideoIndex];

  const filteredVideos = videoData.filter((data) =>
    data.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <Sidebar>
      <div>
        <main className="lg:min-h-[calc(100vh_-_347px)] relative">
          <section className="bg-0">
            <div className="px-10 py-6">
              <section className="grid grid-cols-3 gap-4 lg:gap-8">
                <div className="col-span-full w-full space-y-8 lg:col-span-2">
                  <div className="z-10 flex aspect-video w-full flex-col justify-center">
                    <div className="relative mb-5 h-full">
                      <div className="flex h-full w-full items-center justify-center">
                        <div className="aspect-video w-full">
                          <div style={{ width: "100%", height: "100%" }}>
                            {currentVideo ? (
                              <ReactPlayer
                                url={currentVideo?.video_url}
                                width="100%"
                                height="360px"
                                controls
                                playing
                              />
                            ) : (
                              <ReactPlayer
                                url="https://drive.google.com/file/d/1FldqiQaL9_xoLxT4TwGY012kOq-eUPS0/view"
                                width="100%"
                                height="360px"
                                controls
                                playing
                              />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <button
                        onClick={() => handleVideoChange("prev")}
                        className="bg-coching-button_color flex text-[12px] items-center justify-center gap-2 p-[10px] rounded-[32px]"
                      >
                        <FaArrowLeft color="white" />
                        <span className="text-white">Prev Lesson</span>
                      </button>
                      <button
                        onClick={() => handleVideoChange("next")}
                        className="bg-coching-button_color text-[12px] flex items-center justify-center gap-2 p-[10px] rounded-[32px]"
                      >
                        <span className="text-white">Next Lesson</span>
                        <FaArrowRight color="white" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-[#F8FAFC] border-gray-50 border-light-1 shadow-1 col-span-full h-max rounded-md border pb-1 lg:col-span-1 lg:rounded-lg">
                  <div className="rounded-t-md p-3 dark:bg-slate-900 lg:rounded-t-lg">
                    <div className="flex items-center justify-center">
                      <div className="w-full">
                        <div className="bg-[#F8FAFC] border rounded-md p-1 text-black flex items-center pl-2">
                          <IoSearchOutline color="black" size={20} />
                          <input
                            type="text"
                            className="bg-[#F8FAFC] text-black"
                            placeholder="search content"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flow-root px-4 py-2 bg-white border-t">
                    <div className="mantine-ScrollArea-root h-max lg:h-[calc(100vh_-_250px)]">
                      {filteredVideos.map((data) => (
                        <div
                          key={data.idChapters}
                          className="lg:w-full border-b"
                        >
                          <div
                            className="text-[#504f4f] flex transition pt-3 hover:bg-[#31972a] hover:text-white lg:pt-4 lg:pl-2 pr-3 pb-4 justify-start cursor-pointer gap-5"
                            onClick={() => handlePreviewReply(data.idChapters)} // Toggle chapter visibility
                          >
                            <div className="lg:ml-0 ml-2 text-[#94A3bb]">
                              {Openvisible && Previewid === data.idChapters ? (
                                <IoIosArrowUp size={18} />
                              ) : (
                                <IoIosArrowDown size={18} />
                              )}
                            </div>
                            <div className="flex flex-col items-start">
                              <div>
                                <h3 className="text-xs lg:text-sm">
                                  {data?.name}
                                </h3>
                              </div>
                            </div>
                          </div>
                          {Openvisible && Previewid === data.idChapters && (
                            <div className="text-slate-400">
                              <ul className="p-1">
                                {data?.Videos.map((item) => (
                                  <li
                                    key={item.id}
                                    className="text-[#504f4f] flex items-start gap-2 lg:gap-4 p-2 pl-7 cursor-pointer px-2 py-2 hover:bg-slate-100"
                                  >
                                    <div>
                                      <HiOutlinePlay
                                        color="rgb(2 132 199)"
                                        size={27}
                                      />
                                    </div>
                                    <div className="lg:w-10/12 w-full">
                                      <button
                                        className="text-[14px] lg:text-[14px]"
                                        onClick={() => handleOpenVideo(item)} // Play video on click
                                      >
                                        {item?.video_name}
                                      </button>
                                    </div>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </section>
        </main>
      </div>
    </Sidebar>
  );
};

export default ContentView;
